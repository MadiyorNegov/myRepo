package repository;

import enamus.Role;
import model.User;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public class UserRepository extends BaseRepository<User> {
    private static final UserRepository userRepository = new UserRepository();

    public static UserRepository getInstance() {
        return userRepository;
    }

    public Optional<User> finByUserName(String username) {
        for (User user : data) {
            if (user.getUsername().equals(username)) {
                return Optional.of(user);

            }
        }
        return Optional.empty();
    }

    public ArrayList<User> getAdmin(Role role) {
        ArrayList<User> admin = new ArrayList<>();
        for (User user : getActive()) {
            if (Objects.equals(user.getRole(), role)) {
                admin.add(user);
            }
        }
        return admin;
    }

    public void stopManager(UUID id, boolean ans) {
        for (User user : data) {
            if (Objects.equals(user.getId(), id)) {
                user.setMissionM(ans);
                return;
            }
        }
    }

    public ArrayList<User> getEmployerPro(UUID id) {
        ArrayList<User> users = new ArrayList<>();
        for (User user : data) {
            if (Objects.equals(user.getProjectId(), id) && (Objects.equals(user.getRole(), Role.DEV_BE) || user.getRole() == Role.DEV_FE || user.getRole() == Role.TESTER)) {
                users.add(user);
            }
        }
        return users;
    }

    public ArrayList<User> getEmployerByProject(UUID id) {
        ArrayList<User> users = new ArrayList<>();
        for (User user : data) {
            if (Objects.equals(user.getProjectId(), id) && user.isActive()) {
                users.add(user);
            }
        }
        return users;
    }
}
