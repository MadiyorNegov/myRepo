package model;

import java.util.UUID;

public abstract class BaseModel {
    {
        id = UUID.randomUUID();
    }
    private UUID id;
    protected  boolean active = true;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
