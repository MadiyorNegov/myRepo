package repository;

import enamus.Status;
import model.Task;

import javax.management.Attribute;
import javax.management.ObjectName;
import java.util.ArrayList;
import java.util.Objects;
import java.util.UUID;

public class TaskRepository extends BaseRepository<Task> {
    public static final TaskRepository taskRepository = new TaskRepository();

    public static TaskRepository getInstance() {
        return taskRepository;
    }
    public void deleteTask(UUID id){
        for (Task task : data) {
            if (Objects.equals(task.getEmployerId(),id) && task.getStatus() != Status.ACCEPTED && task.isActive()){
                task.setEmployerId(null);
                task.setStatus(Status.CREATED);
            }
        }
    }
    public ArrayList<Task> getTaskProjectId(UUID id){
       ArrayList<Task> tasks = new ArrayList<>();

        for (Task task : getActive()) {
            if (Objects.equals(task.getProjectId(),id)){
                tasks.add(task);
            }
            
        }
        return tasks;
    }
}
