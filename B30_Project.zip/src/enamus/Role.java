package enamus;

public enum Role {
    SUPER_ADMIN, ADMIN, MANAGER, TEAM_LEADER_BE, TEAM_LEADER_FE, TESTER, DEV_BE, DEV_FE;
}
