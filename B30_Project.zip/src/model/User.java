package model;

import enamus.Role;

import java.util.UUID;

public class User extends BaseModel{
    private String username;
    private UUID projectId;
    private boolean missionM = true;
    private Role role;

    public User(String username, UUID projectId, boolean missionM, Role role) {
        this.username = username;
        this.projectId = projectId;
        this.missionM = missionM;
        this.role = role;
    }

    public User(UUID projectId, Role role) {
        this.projectId = projectId;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public UUID getProjectId() {
        return projectId;
    }

    public void setProjectId(UUID projectId) {
        this.projectId = projectId;
    }

    public boolean isMissionM() {
        return missionM;
    }

    public void setMissionM(boolean missionM) {
        this.missionM = missionM;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", projectId=" + projectId +
                ", missionM=" + missionM +
                ", role=" + role +
                '}';
    }
}
