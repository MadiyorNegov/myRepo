package model;

import enamus.Status;

import java.util.UUID;

public class Task extends BaseModel {
    private String title;
    private UUID projectId;
    private UUID employerId;

    private Status status = Status.CREATED;

    public Task(String title, UUID projectId, UUID employerId, Status status) {
        this.title = title;
        this.projectId = projectId;
        this.employerId = employerId;
        this.status = status;
    }

    public Task(UUID projectId, Status status) {
        this.projectId = projectId;
        this.status = status;
    }

    public UUID getEmployerId() {
        return employerId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public UUID getProjectId() {
        return projectId;
    }

    public void setProjectId(UUID projectId) {
        this.projectId = projectId;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setEmployerId(UUID employerId) {
        this.employerId = employerId;
    }

    @Override
    public String toString() {
        return "Task{" +
                "title='" + title ;

    }
}


