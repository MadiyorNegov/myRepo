package service;

import model.Project;
import repository.ProjectRepository;

import java.util.ArrayList;
import java.util.UUID;

public class ProjectService extends BaseService<Project, ProjectRepository> {

    private static final ProjectService projectService = new ProjectService(new ProjectRepository());
    public static ProjectService getInstance(){
        return  projectService;
    }

    public ProjectService(ProjectRepository repository) {
        super(repository);
    }
    public ArrayList<Project> getAllProject(boolean isActive){
        return repository.getAllProjectId(isActive);
    }
    public ArrayList<Project> getShowProjects(UUID managerId){
        return repository.getShowProject(managerId);
    }

    @Override
    public boolean check(Project project) {
        return false;
    }
}
