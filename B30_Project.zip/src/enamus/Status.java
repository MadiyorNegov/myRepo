package enamus;

public enum Status {
    CREATED, IN_PROGRESS, COMPLETED, ACCEPTED
}
