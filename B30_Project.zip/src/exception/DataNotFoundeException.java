package exception;

public class DataNotFoundeException extends Exception{
    public DataNotFoundeException(String message){
        super(message);
    }
}
