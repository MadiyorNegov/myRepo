package repository;

import model.Project;

import java.util.ArrayList;
import java.util.Objects;
import java.util.UUID;

public class ProjectRepository extends BaseRepository<Project> {

    private static final ProjectRepository projectRepository = new ProjectRepository();

    public static ProjectRepository getInstance() {
        return projectRepository;
    }

    public ArrayList<Project> getAllProjectId(boolean active) {
        ArrayList<Project> projects = new ArrayList<>();
        for (Project project : data) {
            if (Objects.equals(project.isActive(), active)) {
                projects.add(project);
            }
        }
        return projects;
    }

    public ArrayList<Project> getShowProject(UUID managerId) {
        ArrayList<Project> list = new ArrayList<>();
        for (Project project : getActive()) {
            if (Objects.equals(project.getManagerId(), managerId)) {
                list.add(project);
            }
        }
        return list;
    }
}
